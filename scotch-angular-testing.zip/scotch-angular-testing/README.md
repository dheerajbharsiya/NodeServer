### Setup

`nvm use 5.0`

`npm install`

`node server.js`

### Test

`npm install -g karma-cli`

`karma start`
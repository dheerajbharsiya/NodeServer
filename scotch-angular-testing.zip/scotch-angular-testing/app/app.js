(function() {
  'use strict';

  angular.module('meetIrl', [
    'ui.router','ui.grid','ui.grid.selection'
  ])
  .config(function($urlRouterProvider, $stateProvider, $qProvider) {
    $urlRouterProvider.otherwise("/");
     $qProvider.errorOnUnhandledRejections(false);
  	  $stateProvider
        .state('index', {
            url: '/index',
            templateUrl: 'index.html'
        })
        .state('index.grid', {
            url: '/grid',
            templateUrl: 'services/users/grid.html',
            controller:'gridCtrl'
        })      
});
  })();

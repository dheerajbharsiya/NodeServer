(function() {
  'use strict';

  angular.module('meetIrl')
  .controller('gridCtrl',['$scope',gridCtrl]);
  function gridCtrl($scope) {
  	$scope.gridApi = {};
  	$scope.gridOptions = {};
  	$scope.gridOptions.columnDefs = [
    { name: 'id', enableCellEdit: false, width: '10%' },
    { name: 'name', displayName: 'Name (editable)', width: '20%' },
    ];
 
 $scope.gridOptions.onRegisterApi = function(gridApi){
          //set gridApi on scope
          $scope.gridApi = gridApi;
          gridApi.edit.on.afterCellEdit($scope,function(rowEntity, colDef, newValue, oldValue){
          });
        };	  
  	var data = [{name:'xx',id:'2'},{name:'dfsdf',id:'3'}];
  	$scope.gridOptions.data = data;
  }
})();

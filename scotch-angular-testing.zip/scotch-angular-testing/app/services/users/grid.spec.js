describe('meetIrl', function () {
    var scope,
    controller,
    uiGrid;
    beforeEach(function () {
        module('meetIrl');
      
    });
    beforeEach(function() {
    module(function($provide) {
        $provide.value('ui.grid', uiGrid);
    });
});

    describe('gridCtrl', function () {
        beforeEach(inject(function ($rootScope, $controller, $compile) {
            scope = $rootScope.$new();
            controller = $controller('gridCtrl', {
                '$scope': scope
            });
            var gridContainer = "<div ui-grid='gridOptions' ui-grid-selection></div>";

            var grid = $compile(gridContainer)(scope); // I've declared scope before as scope = $rootScope.$new();

            scope.$digest();
            console.log('log',scope.gridApi.selection);
        }))
          it('sets the name', function () {
           // expect(scope.name).toBe('Superhero');
        });


      });
  });